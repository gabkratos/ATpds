let data = [
    {
        id: "121w1x",
        elemento: "Níquel",
        peso: 98.8,
        volume: 10,
        long: "50N",
        lag: "159W"
    },
    {
        id: "56nb5g",
        elemento: "Cobalto",
        peso: 0.6,
        volume: 0.5,
        long: "120S",
        lag: "12W"
    },
    {
        id: "2k4o6p",
        elemento: "Cobre",
        peso: 52.8,
        volume: 30,
        long: "151S",
        lag: "160E"
    },
    {
        id: "2erghn",
        elemento: "Mercúrio",
        peso: 2552.30,
        volume: 251,
        long: "93S",
        lag: "72W"
    },
    {
        id: "0192r7",
        elemento: "Sódio",
        peso: 895.8,
        volume: 3,
        long: "179N",
        lag: "1E"
    }
];

// NÃO MEXER NOS DADOS, O CÓDIGO DE VOCÊS DEVE ESTAR A PARTIR DESTA LINHA

let lista = document.getElementById("lista");
let base = document.getElementById("base");

lista.style.fontFamily = "Comic Sans MS";

function search() {
    lista.innerHTML = "";
    for (let i = 0; i < data.length; i++) {
        if (data[i].id == base.value){ 
       lista.innerHTML += 
            `
            <li>
                <p> elemento: ${data[i].elemento} </p>
                <p> peso: ${data[i].peso} </p>
                <p> volume: ${data[i].volume} </p>
                <p> long: ${data[i].long} </p>
                <p> lag: ${data[i].lag} </p>
            </li
            `;
    }}

}
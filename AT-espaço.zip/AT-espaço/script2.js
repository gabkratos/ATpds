let txt1 = document.getElementById("Elemento");
let txt2 = document.getElementById("Peso");
let txt3 = document.getElementById("Volume");
let txt4 = document.getElementById("Latitude");
let txt5 = document.getElementById("Longitude");
let txt6 = document.getElementById("ID");
let label = document.getElementById("label");
let label2 = document.getElementById("label2");
let dados

function change(){
    label.innerHTML =  txt1.value + "," + txt2.value + "," + txt3.value + "," + txt4.value + "," + txt5.value + "," + txt6.value +
      "." ;
    label2.innerHTML = "Elementos cadastrados com sucesso!!";
    dados = [
      {
          id: txt6.value,
          elemento: txt1.value,
          peso: txt2.value,
          volume: txt3.value,
          long: txt4.value,
          lag: txt5.value
      }
    ];
      console.log(dados);
    
}
